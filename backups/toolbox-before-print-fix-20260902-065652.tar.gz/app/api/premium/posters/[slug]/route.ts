import { readFile } from "node:fs/promises";
import path from "node:path";
import { PDFDocument, rgb } from "pdf-lib";
import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteProps = {
  params: Promise<{
    slug: string;
  }>;
};

const BUCKET_NAME = "company-assets";

const posterFileMap: Record<string, string> = {
  "working-at-height-rules": "working-at-height-rules",
  "scaffold-safety-rules": "scaffold-safety-rules",
  "hot-work-safety-rules": "hot-work-safety-rules",
  "confined-space-entry-rules": "confined-space-entry-rules",
  "electrical-safety-rules": "electrical-safety-rules",
  "fire-extinguisher-selection": "fire-extinguisher-selection",
  "emergency-response": "emergency-response",
  "mandatory-ppe": "mandatory-ppe",
  "loto-golden-rules": "loto-golden-rules",
};

function getLocale(request: Request): "tr" | "en" {
  const url = new URL(request.url);
  return url.searchParams.get("locale") === "tr" ? "tr" : "en";
}

function createSafeUrl(request: Request, pathname: string) {
  const forwardedHost = request.headers.get("x-forwarded-host");
  const requestHost = request.headers.get("host");
  const forwardedProto = request.headers.get("x-forwarded-proto");

  let host = forwardedHost || requestHost || "localhost:3000";
  const protocol = forwardedProto || "http";

  if (
    host.startsWith("0.0.0.0") ||
    host.startsWith("[::]") ||
    host.startsWith("::")
  ) {
    const port = host.includes(":")
      ? host.split(":").pop()
      : "3000";

    host = `localhost:${port}`;
  }

  return new URL(pathname, `${protocol}://${host}`);
}

export async function GET(request: Request, { params }: RouteProps) {
  const { slug } = await params;
  const locale = getLocale(request);
  const isTurkish = locale === "tr";

  if (!posterFileMap[slug]) {
    return NextResponse.json(
      {
        error: isTurkish
          ? "Poster bulunamadı."
          : "Poster could not be found.",
      },
      { status: 404 },
    );
  }

  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(
      createSafeUrl(
        request,
        `/${locale}/login?next=/${locale}/posters`,
      ),
    );
  }

  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("plan,role,status")
    .eq("id", user.id)
    .single();

  if (
    profileError ||
    !profile ||
    profile.status === "suspended"
  ) {
    return NextResponse.redirect(
      createSafeUrl(request, `/${locale}/dashboard`),
    );
  }

  const isPremium =
    profile.plan === "premium" || profile.role === "admin";

  if (!isPremium) {
    return NextResponse.redirect(
      createSafeUrl(request, `/${locale}/upgrade`),
    );
  }

  const sourcePdfPath = path.join(
    process.cwd(),
    "public",
    "downloads",
    `${posterFileMap[slug]}-poster-${locale}.pdf`,
  );

  let sourcePdfBytes: Uint8Array;

  try {
    sourcePdfBytes = await readFile(sourcePdfPath);
  } catch (error) {
    console.error("Poster source PDF read error:", error);

    return NextResponse.json(
      {
        error: isTurkish
          ? "Kaynak poster PDF dosyası bulunamadı."
          : "Source poster PDF could not be found.",
      },
      { status: 404 },
    );
  }

  const { data: logoFiles, error: listError } =
    await supabase.storage
      .from(BUCKET_NAME)
      .list(user.id, {
        limit: 20,
      });

  if (listError) {
    console.error("Poster logo list error:", listError);
  }

  const logoFile = logoFiles?.find((file) =>
    /^logo\.(png|jpg|jpeg)$/i.test(file.name),
  );

  /*
    Logo yoksa Premium indirme hata vermesin.
    Standart yüksek çözünürlüklü poster indirilsin.
  */
  if (!logoFile) {
    const standardFilename =
      `${slug}-poster-${locale}-premium.pdf`;

    return new NextResponse(Buffer.from(sourcePdfBytes), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition":
          `attachment; filename="${standardFilename}"`,
        "Cache-Control": "private, no-store, max-age=0",
      },
    });
  }

  const logoPath = `${user.id}/${logoFile.name}`;

  const { data: logoBlob, error: logoDownloadError } =
    await supabase.storage
      .from(BUCKET_NAME)
      .download(logoPath);

  if (logoDownloadError || !logoBlob) {
    console.error(
      "Poster logo download error:",
      logoDownloadError,
    );

    return new NextResponse(Buffer.from(sourcePdfBytes), {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition":
          `attachment; filename="${slug}-poster-${locale}-premium.pdf"`,
        "Cache-Control": "private, no-store, max-age=0",
      },
    });
  }

  try {
    const pdfDocument = await PDFDocument.load(sourcePdfBytes);
    const firstPage = pdfDocument.getPages()[0];

    if (!firstPage) {
      throw new Error("Poster PDF contains no pages.");
    }

    const logoBytes = new Uint8Array(
      await logoBlob.arrayBuffer(),
    );

    const extension = logoFile.name
      .split(".")
      .pop()
      ?.toLowerCase();

    const embeddedLogo =
      extension === "png"
        ? await pdfDocument.embedPng(logoBytes)
        : extension === "jpg" || extension === "jpeg"
          ? await pdfDocument.embedJpg(logoBytes)
          : null;

    if (!embeddedLogo) {
      return NextResponse.json(
        {
          error: isTurkish
            ? "Logolu poster için PNG veya JPG logo yükleyin."
            : "Upload a PNG or JPG logo for branded posters.",
        },
        { status: 415 },
      );
    }

    const { width: pageWidth, height: pageHeight } =
      firstPage.getSize();

    /*
      Posterlerde logoyu içerik üzerine bindirmemek için
      alt sağ köşede kontrollü ve oranı korunarak gösteriyoruz.
    */
    const maxLogoWidth = 92;
    const maxLogoHeight = 28;

    const scale = Math.min(
      maxLogoWidth / embeddedLogo.width,
      maxLogoHeight / embeddedLogo.height,
      1,
    );

    const logoWidth = embeddedLogo.width * scale;
    const logoHeight = embeddedLogo.height * scale;

    const padding = 5;
    const boxWidth = logoWidth + padding * 2;
    const boxHeight = logoHeight + padding * 2;

    const boxX = pageWidth - boxWidth - 12;
    const boxY = pageHeight - boxHeight - 7;

    firstPage.drawRectangle({
      x: boxX,
      y: boxY,
      width: boxWidth,
      height: boxHeight,
      color: rgb(1, 1, 1),
      borderWidth: 0,
      opacity: 0.96,
    });

    firstPage.drawImage(embeddedLogo, {
      x: boxX + padding,
      y: boxY + padding,
      width: logoWidth,
      height: logoHeight,
    });

    const brandedPdfBytes = await pdfDocument.save();

    const filename =
      `${slug}-poster-${locale}-branded.pdf`;

    return new NextResponse(
      new Uint8Array(brandedPdfBytes),
      {
        status: 200,
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition":
            `attachment; filename="${filename}"`,
          "Cache-Control": "private, no-store, max-age=0",
        },
      },
    );
  } catch (error) {
    console.error("Branded poster generation error:", error);

    return NextResponse.json(
      {
        error: isTurkish
          ? "Logolu poster oluşturulamadı."
          : "The branded poster could not be generated.",
      },
      { status: 500 },
    );
  }
}
