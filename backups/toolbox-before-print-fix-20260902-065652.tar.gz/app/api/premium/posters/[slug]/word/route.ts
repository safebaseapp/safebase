import {
  AlignmentType,
  BorderStyle,
  Document,
  Footer,
  HeadingLevel,
  ImageRun,
  Packer,
  PageNumber,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
} from "docx";
import { NextResponse } from "next/server";
import { createClient } from "@/utils/supabase/server";
import posterRecords from "@/lib/posters/poster-word-data.json";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Locale = "tr" | "en";

type RouteProps = {
  params: Promise<{
    slug: string;
  }>;
};

type UnknownRecord = Record<string, unknown>;

const BUCKET_NAME = "company-assets";

function normalizePosterKey(value: string) {
  return value
    .toLowerCase()
    .replace(/-poster$/g, "")
    .replace(/-safety/g, "")
    .replace(/-rules/g, "")
    .replace(/-entry/g, "")
    .replace(/-golden/g, "")
    .replace(/-selection/g, "")
    .replace(/-mandatory/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function getLocale(request: Request): Locale {
  const url = new URL(request.url);

  return url.searchParams.get("locale") === "tr"
    ? "tr"
    : "en";
}

function createSafeUrl(request: Request, pathname: string) {
  const forwardedHost = request.headers.get("x-forwarded-host");
  const requestHost = request.headers.get("host");
  const forwardedProto = request.headers.get("x-forwarded-proto");

  let host = forwardedHost || requestHost || "localhost:3000";
  const protocol = forwardedProto || "http";

  if (
    host.startsWith("0.0.0.0") ||
    host.startsWith("[::]") ||
    host.startsWith("::")
  ) {
    const port = host.includes(":")
      ? host.split(":").pop()
      : "3000";

    host = `localhost:${port}`;
  }

  return new URL(pathname, `${protocol}://${host}`);
}

function isRecord(value: unknown): value is UnknownRecord {
  return (
    Boolean(value) &&
    typeof value === "object" &&
    !Array.isArray(value)
  );
}

function textValue(value: unknown, fallback = "") {
  return typeof value === "string" && value.trim()
    ? value.trim()
    : fallback;
}

function textArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value
      .filter((item): item is string => typeof item === "string")
      .map((item) => item.trim())
      .filter(Boolean);
  }

  if (typeof value === "string" && value.trim()) {
    return [value.trim()];
  }

  return [];
}

type PosterBlock = {
  heading: string;
  items: string[];
};

function posterBlocks(value: unknown): PosterBlock[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.flatMap((item) => {
    if (!isRecord(item)) {
      return [];
    }

    const heading = textValue(item.heading);
    const items = textArray(item.items);

    if (!heading && items.length === 0) {
      return [];
    }

    return [{ heading, items }];
  });
}

async function getCompanyLogo(
  supabase: Awaited<ReturnType<typeof createClient>>,
  userId: string,
) {
  const { data: files, error: listError } =
    await supabase.storage
      .from(BUCKET_NAME)
      .list(userId, {
        limit: 20,
      });

  if (listError) {
    console.error("Poster Word logo list error:", listError);
    return null;
  }

  const logoFile = files?.find((file) =>
    /^logo\.(png|jpg|jpeg)$/i.test(file.name),
  );

  if (!logoFile) {
    return null;
  }

  const { data: logoBlob, error: downloadError } =
    await supabase.storage
      .from(BUCKET_NAME)
      .download(`${userId}/${logoFile.name}`);

  if (downloadError || !logoBlob) {
    console.error(
      "Poster Word logo download error:",
      downloadError,
    );

    return null;
  }

  const extension = logoFile.name
    .split(".")
    .pop()
    ?.toLowerCase();

  return {
    bytes: new Uint8Array(await logoBlob.arrayBuffer()),
    type: extension === "png" ? "png" : "jpg",
  } as const;
}

function createRuleBlock(
  index: number,
  heading: string,
  items: string[],
) {
  const colors = [
    "DC2626",
    "EA580C",
    "16A34A",
    "2563EB",
    "7C3AED",
    "0891B2",
  ];

  const color = colors[(index - 1) % colors.length];

  return new Table({
    width: {
      size: 100,
      type: WidthType.PERCENTAGE,
    },
    margins: {
      top: 80,
      bottom: 80,
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: {
              size: 17,
              type: WidthType.PERCENTAGE,
            },
            verticalAlign: "center",
            shading: {
              type: ShadingType.CLEAR,
              fill: color,
            },
            margins: {
              top: 180,
              bottom: 180,
              left: 100,
              right: 100,
            },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: String(index).padStart(2, "0"),
                    bold: true,
                    color: "FFFFFF",
                    size: 38,
                  }),
                ],
              }),
            ],
          }),

          new TableCell({
            width: {
              size: 83,
              type: WidthType.PERCENTAGE,
            },
            margins: {
              top: 130,
              bottom: 130,
              left: 220,
              right: 180,
            },
            children: [
              new Paragraph({
                spacing: {
                  after: 100,
                },
                children: [
                  new TextRun({
                    text: heading,
                    bold: true,
                    color,
                    size: 25,
                  }),
                ],
              }),

              ...items.map(
                (item) =>
                  new Paragraph({
                    bullet: {
                      level: 0,
                    },
                    spacing: {
                      after: 60,
                      line: 280,
                    },
                    children: [
                      new TextRun({
                        text: item,
                        color: "475569",
                        size: 19,
                      }),
                    ],
                  }),
              ),
            ],
          }),
        ],
      }),
    ],
  });
}

function createStopWorkBlock(
  title: string,
  items: string[],
) {
  const leftItems = items.filter((_, index) => index % 2 === 0);
  const rightItems = items.filter((_, index) => index % 2 === 1);

  const column = (values: string[]) =>
    new TableCell({
      width: {
        size: 50,
        type: WidthType.PERCENTAGE,
      },
      shading: {
        type: ShadingType.CLEAR,
        fill: "07142E",
      },
      margins: {
        top: 100,
        bottom: 160,
        left: 240,
        right: 180,
      },
      children: values.map(
        (item) =>
          new Paragraph({
            spacing: {
              after: 80,
            },
            children: [
              new TextRun({
                text: `✓ ${item}`,
                color: "FFFFFF",
                size: 18,
              }),
            ],
          }),
      ),
    });

  return new Table({
    width: {
      size: 100,
      type: WidthType.PERCENTAGE,
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            columnSpan: 2,
            shading: {
              type: ShadingType.CLEAR,
              fill: "07142E",
            },
            margins: {
              top: 150,
              bottom: 100,
              left: 160,
              right: 160,
            },
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: title,
                    bold: true,
                    color: "FFFFFF",
                    size: 24,
                  }),
                ],
              }),
            ],
          }),
        ],
      }),

      new TableRow({
        children: [
          column(leftItems),
          column(rightItems),
        ],
      }),
    ],
  });
}

export async function GET(
  request: Request,
  { params }: RouteProps,
) {
  const { slug } = await params;
  const locale = getLocale(request);
  const isTurkish = locale === "tr";

  const normalizedSlug = normalizePosterKey(slug);

  const poster = posterRecords.find((record) => {
    const recordBase =
      typeof record.base === "string" ? record.base : "";

    return (
      recordBase === slug ||
      normalizePosterKey(recordBase) === normalizedSlug
    );
  });

  if (!poster) {
    return NextResponse.json(
      {
        error: isTurkish
          ? "Poster içeriği bulunamadı."
          : "Poster content could not be found.",
      },
      { status: 404 },
    );
  }

  const localizedUnknown = poster[locale];

  if (!isRecord(localizedUnknown)) {
    return NextResponse.json(
      {
        error: isTurkish
          ? "Poster dil içeriği bulunamadı."
          : "Localized poster content could not be found.",
      },
      { status: 404 },
    );
  }

  const content = localizedUnknown;
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(
      createSafeUrl(
        request,
        `/${locale}/login?next=/${locale}/posters`,
      ),
    );
  }

  const { data: profile, error: profileError } =
    await supabase
      .from("profiles")
      .select("plan,role,status")
      .eq("id", user.id)
      .single();

  if (
    profileError ||
    !profile ||
    profile.status === "suspended"
  ) {
    return NextResponse.redirect(
      createSafeUrl(request, `/${locale}/dashboard`),
    );
  }

  const isPremium =
    profile.plan === "premium" ||
    profile.role === "admin";

  if (!isPremium) {
    return NextResponse.redirect(
      createSafeUrl(request, `/${locale}/upgrade`),
    );
  }

  const logo = await getCompanyLogo(supabase, user.id);

  const title = textValue(
    content.title,
    isTurkish ? "GÜVENLİK POSTERİ" : "SAFETY POSTER",
  );

  const subtitle = textValue(content.subtitle);
  const alert = textValue(content.alert);
  const blocks = posterBlocks(content.blocks);

  const footerTitle = textValue(
    content.footer_title,
    isTurkish
      ? "İŞİ DERHAL DURDUR"
      : "STOP WORK IMMEDIATELY",
  );

  const footerItems = textArray(content.footer_items);

  const children: Array<Paragraph | Table> = [];

  if (logo) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.RIGHT,
        spacing: {
          after: 80,
        },
        children: [
          new ImageRun({
            data: logo.bytes,
            type: logo.type,
            transformation: {
              width: 145,
              height: 42,
            },
          }),
        ],
      }),
    );
  }

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: {
        after: 90,
      },
      children: [
        new TextRun({
          text: title,
          bold: true,
          color: "07142E",
          size: 38,
        }),
      ],
    }),
  );

  if (subtitle) {
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: {
          after: 140,
        },
        children: [
          new TextRun({
            text: subtitle,
            color: "64748B",
            size: 21,
          }),
        ],
      }),
    );
  }

  if (alert) {
    children.push(
      new Table({
        width: {
          size: 100,
          type: WidthType.PERCENTAGE,
        },
        rows: [
          new TableRow({
            children: [
              new TableCell({
                shading: {
                  type: ShadingType.CLEAR,
                  fill: "DC2626",
                },
                margins: {
                  top: 130,
                  bottom: 130,
                  left: 130,
                  right: 130,
                },
                children: [
                  new Paragraph({
                    alignment: AlignmentType.CENTER,
                    children: [
                      new TextRun({
                        text: alert,
                        bold: true,
                        color: "FFFFFF",
                        size: 22,
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
      new Paragraph({
        spacing: {
          after: 120,
        },
      }),
    );
  }

  blocks.forEach((block, index) => {
    children.push(
      createRuleBlock(
        index + 1,
        block.heading,
        block.items,
      ),
    );

    children.push(
      new Paragraph({
        spacing: {
          after: 85,
        },
      }),
    );
  });

  if (footerItems.length > 0) {
    children.push(
      createStopWorkBlock(footerTitle, footerItems),
    );
  }

  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: {
        before: 130,
      },
      children: [
        new TextRun({
          text: isTurkish
            ? "SERNEM Profesyonel HSE Poster Kütüphanesi"
            : "SERNEM Professional HSE Poster Library",
          bold: true,
          color: "64748B",
          size: 14,
        }),
      ],
    }),
  );

  const document = new Document({
    creator: "SERNEM",
    title,
    description: subtitle,
    sections: [
      {
        properties: {
          page: {
            size: {
              width: 16838,
              height: 23811,
            },
            margin: {
              top: 620,
              right: 700,
              bottom: 600,
              left: 700,
            },
          },
        },

        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                border: {
                  top: {
                    color: "CBD5E1",
                    style: BorderStyle.SINGLE,
                    size: 4,
                  },
                },
                children: [
                  new TextRun({
                    text: "SERNEM • ",
                    color: "64748B",
                    size: 14,
                  }),

                  new TextRun({
                    children: [PageNumber.CURRENT],
                    color: "64748B",
                    size: 14,
                  }),
                ],
              }),
            ],
          }),
        },

        children,
      },
    ],
  });

  const buffer = await Packer.toBuffer(document);

  const filename =
    `${slug}-poster-${locale}-editable.docx`;

  return new NextResponse(
    new Uint8Array(buffer),
    {
      status: 200,
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "Content-Disposition":
          `attachment; filename="${filename}"`,
        "Cache-Control":
          "private, no-store, max-age=0",
      },
    },
  );
}
