"use client";

import Image from "next/image";
import Link from "next/link";
import { FormEvent, KeyboardEvent, useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import RiskSummaryCard from "@/components/ai/RiskSummaryCard";
import {
  getRecommendations,
  type Recommendation,
} from "@/lib/ai/recommendations";

import type { CopilotResponse } from "@/lib/ai/copilot-types";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: string[];
  recommendations?: Recommendation[];
  copilot?: CopilotResponse;
};

const sourceNames: Record<string, { tr: string; en: string }> = {
  "ppe.md": {
    tr: "Kişisel Koruyucu Donanım",
    en: "Personal Protective Equipment",
  },
  "grinding.md": {
    tr: "Taşlama Çalışmaları",
    en: "Grinding Operations",
  },
  "hot-work.md": {
    tr: "Sıcak İş Çalışmaları",
    en: "Hot Work",
  },
  "confined-space.md": {
    tr: "Kapalı Alan Çalışmaları",
    en: "Confined Space",
  },
  "loto.md": {
    tr: "Kilitleme ve Etiketleme",
    en: "Lockout Tagout",
  },
  "working-at-height.md": {
    tr: "Yüksekte Çalışma",
    en: "Working at Height",
  },
  "excavation.md": {
    tr: "Kazı Çalışmaları",
    en: "Excavation",
  },
  "scaffolding.md": {
    tr: "İskele Güvenliği",
    en: "Scaffolding Safety",
  },
  "electrical-safety.md": {
    tr: "Elektrik Güvenliği",
    en: "Electrical Safety",
  },
  "fire-safety.md": {
    tr: "Yangın Güvenliği",
    en: "Fire Safety",
  },
  "crane-safety.md": {
    tr: "Vinç ve Kaldırma Güvenliği",
    en: "Crane and Lifting Safety",
  },
  "chemical-safety.md": {
    tr: "Kimyasal Güvenlik",
    en: "Chemical Safety",
  },
};

function createMessageId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function copilotToMarkdown(
  copilot: CopilotResponse,
  isTurkish: boolean,
): string {
  const sections: string[] = [];

  const addList = (title: string, items: string[]) => {
    if (items.length > 0) {
      sections.push(
        `## ${title}\n\n${items.map((item) => `- ${item}`).join("\n")}`,
      );
    }
  };

  sections.push(
    `## ${isTurkish ? "Genel Bakış" : "Overview"}\n\n${copilot.summary}`,
  );

  if (copilot.riskReason) {
    sections.push(
      `## ${isTurkish ? "Ön Risk Değerlendirmesi" : "Preliminary Risk Assessment"}\n\n**${copilot.riskLevel}** — ${copilot.riskReason}`,
    );
  }

  addList(
    isTurkish ? "Ana Tehlikeler" : "Main Hazards",
    copilot.hazards,
  );

  addList(
    isTurkish ? "Kritik Kontroller" : "Critical Controls",
    copilot.criticalControls,
  );

  addList(
    isTurkish ? "Gerekli KKD" : "Required PPE",
    copilot.requiredPpe,
  );

  addList(
    isTurkish ? "İzinler ve Dokümanlar" : "Permits and Documents",
    copilot.permitsAndDocuments,
  );

  addList(
    isTurkish ? "Çalışma Öncesi" : "Before Starting",
    copilot.beforeStarting,
  );

  addList(
    isTurkish ? "Çalışma Sırasında" : "During the Work",
    copilot.duringWork,
  );

  addList(
    isTurkish ? "Çalışma Sonrası" : "After Completion",
    copilot.afterCompletion,
  );

  addList(
    isTurkish
      ? "Çalışmayı Derhal Durdurun"
      : "Stop Work Immediately If",
    copilot.stopWorkConditions,
  );

  addList(
    isTurkish ? "Yaygın Hatalar" : "Common Failures",
    copilot.commonFailures,
  );

  addList(
    isTurkish ? "Uygulanabilir Standartlar" : "Applicable Standards",
    copilot.applicableStandards,
  );

  addList(
    isTurkish ? "SERNEM Hızlı Kontrol Listesi" : "SERNEM Quick Checklist",
    copilot.quickChecklist.map((item) => `☐ ${item}`),
  );

  if (copilot.recommendation) {
    sections.push(
      `## ${isTurkish ? "SERNEM Önerisi" : "SERNEM Recommendation"}\n\n${copilot.recommendation}`,
    );
  }

  if (copilot.clarificationQuestions.length > 0) {
    addList(
      isTurkish ? "Netleştirilmesi Gerekenler" : "Clarification Required",
      copilot.clarificationQuestions,
    );
  }

  return sections.join("\n\n");
}

export default function AIAssistantPage() {
  const pathname = usePathname();
  const isTurkish = pathname.startsWith("/tr");
  const locale = isTurkish ? "tr" : "en";

  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const quickQuestions = isTurkish
    ? [
        {
          label: "Kapalı Alan",
          question:
            "Kapalı alana giriş öncesinde hangi kontroller yapılmalıdır?",
        },
        {
          label: "Sıcak İş",
          question:
            "Sıcak işe başlamadan önce hangi kritik kontroller gereklidir?",
        },
        {
          label: "LOTO",
          question: "LOTO uygulamasının temel adımları nelerdir?",
        },
        {
          label: "KKD",
          question:
            "Taşlama çalışması için hangi kişisel koruyucu donanımlar gereklidir?",
        },
      ]
    : [
        {
          label: "Confined Space",
          question: "What checks are required before confined-space entry?",
        },
        {
          label: "Hot Work",
          question:
            "What critical controls are required before hot work begins?",
        },
        {
          label: "LOTO",
          question: "What are the essential steps of a LOTO procedure?",
        },
        {
          label: "PPE",
          question:
            "What personal protective equipment is required for grinding work?",
        },
      ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "end",
    });
  }, [messages.length, loading]);

  const askAI = async (questionOverride?: string) => {
    const cleanQuestion = (questionOverride ?? question).trim();

    if (!cleanQuestion || loading) {
      if (!cleanQuestion) {
        setError(
          isTurkish
            ? "Lütfen bir HSE sorusu girin."
            : "Please enter an HSE question.",
        );
      }

      return;
    }

    const userMessage: Message = {
      id: createMessageId(),
      role: "user",
      content: cleanQuestion,
    };

    setMessages((current) => [...current, userMessage]);
    setQuestion("");
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          question: cleanQuestion,
          locale,
          responseMode: "structured",
          messages: [...messages, userMessage].map((message) => ({
            role: message.role,
            content: message.content,
          })),
        }),
      });

      if (!response.ok) {
        const errorPayload = await response.text();
        console.error("SERNEM structured response error:", errorPayload);
        throw new Error("SERNEM AI structured request failed.");
      }

      const payload = (await response.json()) as {
        data?: CopilotResponse;
        sources?: string[];
      };

      if (!payload.data) {
        throw new Error("SERNEM Copilot data is unavailable.");
      }

      const copilot = payload.data;
      const responseSources = Array.isArray(payload.sources)
        ? payload.sources
        : [];

      const assistantMessage: Message = {
        id: createMessageId(),
        role: "assistant",
        content: copilotToMarkdown(copilot, isTurkish),
        sources: responseSources,
        recommendations: getRecommendations(cleanQuestion),
        copilot,
      };

      setMessages((current) => [...current, assistantMessage]);
    } catch (requestError) {
      console.error(requestError);

      setError(
        isTurkish
          ? "SERNEM AI isteğinizi işleyemedi. Lütfen tekrar deneyin."
          : "SERNEM AI could not process your request. Please try again.",
      );
    } finally {
      setLoading(false);
      textareaRef.current?.focus();
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void askAI();
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void askAI();
    }
  };

  const startNewChat = () => {
    setMessages([]);
    setQuestion("");
    setError("");
    setCopiedMessageId(null);
    textareaRef.current?.focus();
  };

  const copyMessage = async (message: Message) => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopiedMessageId(message.id);

      window.setTimeout(() => {
        setCopiedMessageId(null);
      }, 1800);
    } catch {
      setError(
        isTurkish
          ? "Yanıt panoya kopyalanamadı."
          : "The response could not be copied.",
      );
    }
  };

  return (
    <main className="min-h-[calc(100vh-88px)] bg-slate-950 text-white">
      <div className="mx-auto flex min-h-[calc(100vh-88px)] max-w-[1600px]">
        <aside className="hidden w-72 shrink-0 border-r border-white/10 bg-slate-950/90 p-5 lg:flex lg:flex-col">
          <Link
            href={`/${locale}`}
            className="flex items-center gap-3 rounded-2xl px-2 py-2"
          >
            <Image
              src="/brand/sernem-mark.svg"
              alt="SERNEM"
              width={46}
              height={46}
              className="h-11 w-11"
            />

            <div>
              <p className="font-black text-white">SERNEM AI</p>
              <p className="text-xs text-slate-500">
                {isTurkish ? "HSE Bilgi Asistanı" : "HSE Knowledge Assistant"}
              </p>
            </div>
          </Link>

          <button
            type="button"
            onClick={startNewChat}
            className="mt-7 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 font-black text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-500"
          >
            <span className="text-xl">+</span>
            {isTurkish ? "Yeni Sohbet" : "New Chat"}
          </button>

          <div className="mt-8">
            <div className="flex items-center gap-3 px-1">
              <p className="shrink-0 text-[11px] font-black uppercase tracking-[0.22em] text-slate-500">
                {isTurkish ? "Hızlı Konular" : "Quick Topics"}
              </p>
              <div className="h-px flex-1 bg-gradient-to-r from-white/10 to-transparent" />
            </div>

            <div className="mt-4 space-y-2">
              {quickQuestions.map((item, index) => {
                const topicStyles = [
                  {
                    icon: "🛡",
                    iconClass:
                      "border-emerald-400/20 bg-emerald-400/[0.07] text-emerald-300",
                  },
                  {
                    icon: "🔥",
                    iconClass:
                      "border-orange-400/20 bg-orange-400/[0.07] text-orange-300",
                  },
                  {
                    icon: "🔒",
                    iconClass:
                      "border-violet-400/20 bg-violet-400/[0.07] text-violet-300",
                  },
                  {
                    icon: "⛑",
                    iconClass:
                      "border-blue-400/20 bg-blue-400/[0.07] text-blue-300",
                  },
                ][index];

                return (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => void askAI(item.question)}
                    disabled={loading}
                    className="group grid w-full grid-cols-[40px_1fr_20px] items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.025] px-3 py-2.5 text-left transition-all duration-200 hover:translate-x-0.5 hover:border-blue-400/20 hover:bg-blue-500/[0.06] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <span
                      className={`flex h-10 w-10 items-center justify-center rounded-xl border text-sm ${topicStyles.iconClass}`}
                    >
                      {topicStyles.icon}
                    </span>

                    <div className="min-w-0">
                      <p className="truncate text-sm font-black text-slate-200 transition group-hover:text-white">
                        {item.label}
                      </p>
                      <p className="mt-0.5 text-[10px] font-medium text-slate-600 transition group-hover:text-slate-500">
                        {isTurkish ? "Hızlı rehberlik" : "Quick guidance"}
                      </p>
                    </div>

                    <span className="text-sm text-slate-600 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-blue-300">
                      →
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-auto rounded-2xl border border-emerald-400/15 bg-emerald-400/[0.06] p-4">
            <div className="flex items-center gap-2 text-sm font-black text-emerald-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)]" />
              {isTurkish ? "Sistem Aktif" : "System Online"}
            </div>

            <p className="mt-2 text-xs leading-5 text-slate-500">
              {isTurkish
                ? "Yanıtlar SERNEM Bilgi Tabanındaki mevcut kaynaklara dayanır."
                : "Responses are based on the available SERNEM Knowledge Base."}
            </p>
          </div>
        </aside>

        <section className="relative flex min-w-0 flex-1 flex-col">
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.045]"
            style={{
              backgroundImage:
                "linear-gradient(rgba(255,255,255,0.45) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.45) 1px, transparent 1px)",
              backgroundSize: "48px 48px",
            }}
          />

          <header className="relative z-10 flex min-h-20 items-center justify-between border-b border-white/10 bg-slate-950/80 px-4 backdrop-blur-xl sm:px-7">
            <div>
              <h1 className="text-lg font-black sm:text-xl">
                {isTurkish ? "SERNEM AI Asistanı" : "SERNEM AI Assistant"}
              </h1>

              <p className="mt-1 hidden text-sm text-slate-500 sm:block">
                {isTurkish
                  ? "HSE sorularınız için pratik ve kaynaklı rehberlik"
                  : "Practical, source-based guidance for HSE questions"}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={startNewChat}
                className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-sm font-bold text-slate-200 transition hover:bg-white/10 lg:hidden"
              >
                <span>+</span>
                {isTurkish ? "Yeni" : "New"}
              </button>

              <Link
                href={`/${locale}`}
                className="rounded-xl border border-white/10 bg-white/[0.05] px-3 py-2 text-sm font-bold text-slate-300 transition hover:bg-white/10 hover:text-white"
              >
                {isTurkish ? "Ana Sayfa" : "Home"}
              </Link>
            </div>
          </header>

          <div className="relative z-10 flex-1 overflow-y-auto">
            <div className="mx-auto flex min-h-full w-full max-w-6xl flex-col px-5 py-8 sm:px-8 lg:px-10">
              {messages.length === 0 ? (
                <div className="py-5">

                  {/* ================= PREMIUM HERO FINAL ================= */}
                  <section className="relative min-h-[550px] overflow-hidden rounded-[28px] border border-blue-400/20 bg-[#020817] shadow-[0_30px_90px_rgba(0,0,0,.42)]">

                    {/* ATMOSPHERE */}
                    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_78%_45%,rgba(37,99,235,.26),transparent_32%),radial-gradient(circle_at_25%_0%,rgba(14,165,233,.08),transparent_32%)]" />

                    {/* SUBTLE DIGITAL STARS */}
                    <div
                      className="pointer-events-none absolute inset-0 opacity-[0.10]"
                      style={{
                        backgroundImage:
                          "radial-gradient(circle, rgba(96,165,250,.85) 0.8px, transparent 0.9px)",
                        backgroundSize: "42px 42px",
                      }}
                    />

                    {/* CLEAN GLOBE FEEL */}
                    <div className="pointer-events-none absolute -right-[190px] top-[12px] hidden h-[650px] w-[650px] rounded-full bg-[radial-gradient(circle_at_38%_42%,rgba(59,130,246,.34),rgba(30,64,175,.14)_42%,transparent_68%)] lg:block" />

                    <div className="pointer-events-none absolute -right-[185px] top-[55px] hidden h-[585px] w-[585px] rounded-full border border-blue-400/[0.12] lg:block" />

                    <div className="pointer-events-none absolute -right-[110px] top-[130px] hidden h-[430px] w-[430px] rounded-full border border-blue-300/[0.08] lg:block" />

                    {/* MAIN CONTENT */}
                    <div className="relative z-10 flex min-h-[550px] flex-col items-center justify-center px-6 py-7 sm:px-10 lg:px-14">

                      {/* LOGO */}
                      <div className="flex h-[72px] w-[72px] items-center justify-center rounded-[22px] border border-blue-400/35 bg-blue-500/[0.12] shadow-[0_0_40px_rgba(37,99,235,.30)] backdrop-blur">
                        <Image
                          src="/brand/sernem-mark.svg"
                          alt=""
                          width={54}
                          height={54}
                          className="h-[52px] w-[52px]"
                        />
                      </div>

                      {/* EYEBROW */}
                      <p className="mt-5 text-center text-[11px] font-black uppercase tracking-[0.34em] text-emerald-400 sm:text-xs">
                        {isTurkish
                          ? "Sınırların Ötesinde Güvenlik"
                          : "Safety Without Borders"}
                      </p>

                      {/* TITLE */}
                      <h2 className="mx-auto mt-4 max-w-[760px] text-center text-[35px] font-black leading-[0.96] tracking-[-0.045em] text-white sm:text-[44px] lg:text-[52px]">
                        {isTurkish
                          ? "Bugün hangi HSE konusunda yardımcı olabilirim?"
                          : "How can I help with your HSE work today?"}
                      </h2>

                      {/* DESCRIPTION */}
                      <p className="mx-auto mt-5 max-w-[680px] text-center text-sm leading-6 text-slate-400 sm:text-[15px]">
                        {isTurkish
                          ? "KKD, sıcak çalışma, kapalı alan, LOTO ve diğer iş güvenliği konularında sorularınıza anında, kaynaklı ve güvenilir yanıtlar alın."
                          : "Get instant, source-based guidance for PPE, hot work, confined space, LOTO and other HSE topics."}
                      </p>

                      {/* QUESTION BAR */}
                      <form
                        onSubmit={handleSubmit}
                        className="mx-auto mt-7 w-full max-w-[780px] rounded-[18px] border border-blue-400/30 bg-[#020817]/95 p-2 shadow-[0_18px_50px_rgba(0,0,0,.42)] backdrop-blur-xl transition duration-300 focus-within:border-blue-400/70 focus-within:ring-4 focus-within:ring-blue-500/10"
                      >
                        <div className="flex items-center gap-2">

                          <span className="ml-3 flex h-8 w-8 shrink-0 items-center justify-center text-lg text-slate-500">
                            ⌕
                          </span>

                          <textarea
                            ref={textareaRef}
                            value={question}
                            onChange={(event) => {
                              setQuestion(event.target.value);
                              setError("");
                            }}
                            onKeyDown={handleKeyDown}
                            disabled={loading}
                            rows={1}
                            className="max-h-28 min-h-[50px] flex-1 resize-none bg-transparent px-1 py-[15px] text-sm text-white outline-none placeholder:text-slate-500 disabled:cursor-not-allowed sm:text-[15px]"
                            placeholder={
                              isTurkish
                                ? "HSE ile ilgili sorunuzu yazın..."
                                : "Ask your HSE question..."
                            }
                          />

                          <button
                            type="submit"
                            disabled={loading || !question.trim()}
                            className="group relative flex !h-[52px] !w-[58px] min-h-[52px] min-w-[58px] shrink-0 items-center justify-center overflow-hidden rounded-[14px] border border-blue-300/30 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-500 text-xl font-black text-white shadow-[0_8px_28px_rgba(37,99,235,.42)] transition-all duration-300 hover:-translate-y-0.5 hover:scale-[1.04] hover:shadow-[0_12px_34px_rgba(37,99,235,.55)] disabled:translate-y-0 disabled:scale-100 disabled:cursor-not-allowed disabled:opacity-40"
                            aria-label={
                              isTurkish ? "Soruyu gönder" : "Send question"
                            }
                          >
                            <span className="transition-transform duration-300 group-hover:translate-x-0.5">
                              →
                            </span>
                          </button>

                        </div>
                      </form>

                      {error && (
                        <div className="mx-auto mt-3 w-full max-w-[780px] rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-left text-sm font-semibold text-red-300">
                          ⚠️ {error}
                        </div>
                      )}

                      {/* TRUST STRIP */}
                      <div className="mx-auto mt-4 grid w-full max-w-[900px] gap-3 sm:grid-cols-2 lg:grid-cols-4">

                        <div className="group flex min-h-[72px] items-center gap-3 rounded-2xl border border-white/[0.08] bg-[#061126]/80 px-4 py-3 text-left backdrop-blur transition hover:-translate-y-0.5 hover:border-cyan-400/20 hover:bg-[#081630]">
                          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-400/[0.07] text-cyan-300">
                            ◉
                          </span>
                          <div>
                            <p className="text-xs font-black text-white">
                              {isTurkish ? "Kaynaklı Yanıtlar" : "Source-Based"}
                            </p>
                            <p className="mt-1 text-[10px] leading-4 text-slate-500">
                              OSHA, ISO, NEBOSH
                            </p>
                          </div>
                        </div>

                        <div className="group flex min-h-[72px] items-center gap-3 rounded-2xl border border-white/[0.08] bg-[#061126]/80 px-4 py-3 text-left backdrop-blur transition hover:-translate-y-0.5 hover:border-cyan-400/20 hover:bg-[#081630]">
                          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-cyan-400/20 bg-cyan-400/[0.07] text-cyan-300">
                            ◷
                          </span>
                          <div>
                            <p className="text-xs font-black text-white">
                              {isTurkish ? "7/24 Erişim" : "24/7 Access"}
                            </p>
                            <p className="mt-1 text-[10px] leading-4 text-slate-500">
                              {isTurkish ? "Her an, her yerde" : "Anytime, anywhere"}
                            </p>
                          </div>
                        </div>

                        <div className="group flex min-h-[72px] items-center gap-3 rounded-2xl border border-white/[0.08] bg-[#061126]/80 px-4 py-3 text-left backdrop-blur transition hover:-translate-y-0.5 hover:border-emerald-400/20 hover:bg-[#081630]">
                          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-emerald-400/20 bg-emerald-400/[0.07] text-emerald-300">
                            ✓
                          </span>
                          <div>
                            <p className="text-xs font-black text-white">
                              {isTurkish ? "Pratik Rehberlik" : "Practical Guidance"}
                            </p>
                            <p className="mt-1 text-[10px] leading-4 text-slate-500">
                              {isTurkish ? "Sahaya yönelik çözümler" : "Field-ready solutions"}
                            </p>
                          </div>
                        </div>

                        <div className="group flex min-h-[72px] items-center gap-3 rounded-2xl border border-white/[0.08] bg-[#061126]/80 px-4 py-3 text-left backdrop-blur transition hover:-translate-y-0.5 hover:border-blue-400/20 hover:bg-[#081630]">
                          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-blue-400/20 bg-blue-400/[0.07] text-blue-300">
                            ◆
                          </span>
                          <div>
                            <p className="text-xs font-black text-white">
                              {isTurkish ? "Gizlilik & Güvenlik" : "Privacy & Security"}
                            </p>
                            <p className="mt-1 text-[10px] leading-4 text-slate-500">
                              {isTurkish ? "Profesyonel kullanım" : "Professional use"}
                            </p>
                          </div>
                        </div>

                      </div>
                    </div>
                  </section>


                  {/* ============== QUICK TOPICS ============== */}
                  <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">

                    {quickQuestions.map((item, index) => {
                      const designs = [
                        {
                          border: "border-emerald-400/30",
                          bg: "bg-emerald-500/[0.04]",
                          icon: "🛡️",
                        },
                        {
                          border: "border-orange-400/30",
                          bg: "bg-orange-500/[0.04]",
                          icon: "🔥",
                        },
                        {
                          border: "border-violet-400/30",
                          bg: "bg-violet-500/[0.04]",
                          icon: "🔒",
                        },
                        {
                          border: "border-blue-400/30",
                          bg: "bg-blue-500/[0.04]",
                          icon: "⛑️",
                        },
                      ][index];

                      return (
                        <button
                          key={item.label}
                          type="button"
                          disabled={loading}
                          onClick={() => void askAI(item.question)}
                          className={`group min-h-[165px] rounded-2xl border ${designs.border} ${designs.bg} p-5 text-left transition duration-300 hover:-translate-y-1 hover:bg-white/[0.055] disabled:cursor-not-allowed disabled:opacity-50`}
                        >
                          <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-slate-950/60 text-xl">
                            {designs.icon}
                          </span>

                          <p className="mt-4 text-base font-black text-white">
                            {item.label}
                          </p>

                          <p className="mt-2 text-sm leading-6 text-slate-400">
                            {item.question}
                          </p>

                          <span className="mt-4 inline-flex items-center gap-2 rounded-lg border border-white/10 bg-slate-950/50 px-3 py-2 text-xs font-black text-slate-300 transition group-hover:text-white">
                            {isTurkish ? "Konuyu Sor" : "Ask Topic"} →
                          </span>
                        </button>
                      );
                    })}

                  </div>

                </div>
              ) : (
                <div className="space-y-8 pb-6">
                  {messages.map((message) => (
                    <article
                      key={message.id}
                      className={`flex gap-3 sm:gap-4 ${
                        message.role === "user"
                          ? "justify-end"
                          : "justify-start"
                      }`}
                    >
                      {message.role === "assistant" && (
                        <div className="mt-1 hidden h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-blue-400/20 bg-blue-500/10 sm:flex">
                          <Image
                            src="/brand/sernem-mark.svg"
                            alt=""
                            width={32}
                            height={32}
                            className="h-8 w-8"
                          />
                        </div>
                      )}

                      <div
                        className={`max-w-[92%] rounded-3xl border p-5 sm:max-w-[82%] sm:p-6 ${
                          message.role === "user"
                            ? "border-blue-500/30 bg-blue-600 text-white shadow-xl shadow-blue-600/10"
                            : "border-white/10 bg-white/[0.055] text-slate-200 shadow-xl shadow-black/10"
                        }`}
                      >
                        <div className="mb-4 flex items-center justify-between gap-4">
                          <p
                            className={`text-xs font-black uppercase tracking-[0.16em] ${
                              message.role === "user"
                                ? "text-blue-100"
                                : "text-emerald-300"
                            }`}
                          >
                            {message.role === "user"
                              ? isTurkish
                                ? "Siz"
                                : "You"
                              : "SERNEM AI"}
                          </p>

                          {message.role === "assistant" && (
                            <button
                              type="button"
                              onClick={() => void copyMessage(message)}
                              className="rounded-lg px-2 py-1 text-xs font-bold text-slate-400 transition hover:bg-white/10 hover:text-white"
                            >
                              {copiedMessageId === message.id
                                ? isTurkish
                                  ? "Kopyalandı"
                                  : "Copied"
                                : isTurkish
                                  ? "Kopyala"
                                  : "Copy"}
                            </button>
                          )}
                        </div>

                        {message.role === "user" ? 
                        ( 
                          <p className="whitespace-pre-wrap leading-7">
                            {message.content.replace(
  /\((hot-work|permit-to-work|confined-space|confined\s+space|loto|lockout-tagout|excavation|scaffolding|manual-handling|working-at-height|ppe)\)/gi,
  ""
).replace(/Genel Bakarış/gi, "Genel Bakış")}
                          </p>
                        ) : (
                          <>
                            {message.copilot && (
                              <RiskSummaryCard
                                locale={locale}
                                riskLevel={message.copilot.riskLevel}
                                title={message.copilot.title}
                                summary={message.copilot.summary}
                                riskReason={message.copilot.riskReason}
                                hazards={message.copilot.hazards}
                                criticalControlCount={
                                  message.copilot.criticalControls.length
                                }
                              />
                            )}

                            <ReactMarkdown
                              remarkPlugins={[remarkGfm]}
                            components={{
                              h1: ({ children }) => (
                                <h1 className="mb-4 mt-7 border-b border-white/10 pb-3 text-2xl font-black text-white first:mt-0">
                                  {children}
                                </h1>
                              ),
                              h2: ({ children }) => (
                                <h2 className="mb-3 mt-7 flex items-center gap-2 text-xl font-black text-blue-300 first:mt-0">
                                  <span className="h-2 w-2 rounded-full bg-blue-500" />
                                  {children}
                                </h2>
                              ),
                              h3: ({ children }) => (
                                <h3 className="mb-3 mt-6 text-lg font-bold text-white">
                                  {children}
                                </h3>
                              ),
                              p: ({ children }) => (
                                <p className="mb-4 leading-7 text-slate-300 last:mb-0">
                                  {children}
                                </p>
                              ),
                              ul: ({ children }) => (
                                <ul className="mb-6 space-y-3">{children}</ul>
                              ),
                              ol: ({ children }) => (
                                <ol className="mb-6 list-decimal space-y-3 pl-6 text-slate-300">
                                  {children}
                                </ol>
                              ),
                              li: ({ children }) => (
                                <li className="flex items-start gap-3 leading-7 text-slate-300">
                                  <span className="mt-1.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-xs text-emerald-400">
                                    ✓
                                  </span>
                                  <span>{children}</span>
                                </li>
                              ),
                              strong: ({ children }) => (
                                <strong className="font-black text-white">
                                  {children}
                                </strong>
                              ),
                              blockquote: ({ children }) => (
                                <blockquote className="my-5 rounded-xl border-l-4 border-amber-400 bg-amber-400/10 px-5 py-4 text-amber-100">
                                  {children}
                                </blockquote>
                              ),
                              a: ({ href, children }) => (
                                <a
                                  href={href}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="font-bold text-blue-400 underline decoration-blue-400/40 underline-offset-4 hover:text-blue-300"
                                >
                                  {children}
                                </a>
                              ),
                              code: ({ children }) => (
                                <code className="rounded bg-slate-800 px-1.5 py-0.5 text-sm text-blue-300">
                                  {children}
                                </code>
                              ),
                              hr: () => <hr className="my-7 border-white/10" />,
                            }}
                          >
                            {message.content}
                          </ReactMarkdown>
                          </>
                        )}

                        {message.role === "assistant" &&
                          message.sources &&
                          message.sources.length > 0 && (
                            <div className="mt-6 border-t border-white/10 pt-5">
                              <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-500">
                                {isTurkish
                                  ? "Kullanılan Kaynaklar"
                                  : "Knowledge Sources"}
                              </p>

                              <div className="mt-3 flex flex-wrap gap-2">
                                {message.sources.map((source) => {
                                  const normalizedSource = `${source
                                    .trim()
                                    .toLowerCase()
                                    .replace(/\.md$/, "")
                                    .replaceAll("_", "-")
                                    .replace(/\s+/g, "-")}.md`;

                                  const label =
                                    sourceNames[normalizedSource]?.[
                                      isTurkish ? "tr" : "en"
                                    ] ||
                                    source
                                      .replace(/\.md$/, "")
                                      .replaceAll("-", " ");

                                  return (
                                    <span
                                      key={source}
                                      className="rounded-lg border border-blue-500/20 bg-blue-500/10 px-3 py-2 text-xs font-bold text-blue-300"
                                    >
                                      📄 {label}
                                    </span>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        {message.role === "assistant" &&
                          message.recommendations &&
                          message.recommendations.length > 0 && (
                            <div className="mt-6 border-t border-white/10 pt-5">
                              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                                <div>
                                  <p className="text-xs font-black uppercase tracking-[0.16em] text-emerald-400">
                                    {isTurkish
                                      ? "İlgili SERNEM Kaynakları"
                                      : "Related SERNEM Resources"}
                                  </p>

                                  <p className="mt-2 text-sm leading-6 text-slate-500">
                                    {isTurkish
                                      ? "Sorunuzla ilgili rehberleri, kontrol listelerini ve profesyonel içerikleri açın."
                                      : "Open guides, checklists and professional resources related to your question."}
                                  </p>
                                </div>

                                <span className="w-fit rounded-full border border-emerald-400/15 bg-emerald-400/[0.07] px-3 py-1 text-[11px] font-black uppercase tracking-[0.12em] text-emerald-300">
                                  SERNEM Copilot
                                </span>
                              </div>

                              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                                {message.recommendations.map(
                                  (recommendation) => (
                                    <Link
                                      key={recommendation.id}
                                      href={`/${locale}${recommendation.href}`}
                                      className="group rounded-2xl border border-white/10 bg-slate-950/50 p-4 transition duration-300 hover:-translate-y-0.5 hover:border-blue-400/30 hover:bg-blue-500/[0.08]"
                                    >
                                      <div className="flex items-start gap-3">
                                        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-xl">
                                          {recommendation.icon}
                                        </span>

                                        <div className="min-w-0">
                                          <div className="flex flex-wrap items-center gap-2">
                                            <p className="font-black text-white transition group-hover:text-blue-300">
                                              {
                                                recommendation.title[
                                                  isTurkish ? "tr" : "en"
                                                ]
                                              }
                                            </p>

                                            <span className="rounded-full border border-white/10 bg-white/[0.05] px-2 py-0.5 text-[10px] font-black uppercase tracking-[0.1em] text-slate-400">
                                              {recommendation.type ===
                                              "knowledge"
                                                ? isTurkish
                                                  ? "Rehber"
                                                  : "Guide"
                                                : recommendation.type ===
                                                    "checklist"
                                                  ? isTurkish
                                                    ? "Kontrol Listesi"
                                                    : "Checklist"
                                                  : recommendation.type ===
                                                      "toolbox"
                                                    ? "Toolbox"
                                                    : isTurkish
                                                      ? "Şablon"
                                                      : "Template"}
                                            </span>
                                          </div>

                                          <p className="mt-2 text-sm leading-6 text-slate-500 transition group-hover:text-slate-400">
                                            {
                                              recommendation.description[
                                                isTurkish ? "tr" : "en"
                                              ]
                                            }
                                          </p>

                                          <p className="mt-3 text-xs font-black text-blue-400 transition group-hover:text-blue-300">
                                            {isTurkish
                                              ? "Kaynağı aç →"
                                              : "Open resource →"}
                                          </p>
                                        </div>
                                      </div>
                                    </Link>
                                  ),
                                )}
                              </div>
                            </div>
                          )}

                      </div>
                    </article>
                  ))}

                  {loading && (
                    <article className="flex gap-4">
                      <div className="mt-1 hidden h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-blue-400/20 bg-blue-500/10 sm:flex">
                        <Image
                          src="/brand/sernem-mark.svg"
                          alt=""
                          width={32}
                          height={32}
                          className="h-8 w-8"
                        />
                      </div>

                      <div className="rounded-3xl border border-white/10 bg-white/[0.055] px-6 py-5">
                        <p className="text-xs font-black uppercase tracking-[0.16em] text-emerald-300">
                          SERNEM AI
                        </p>

                        <div className="mt-4 flex items-center gap-2">
                          <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-blue-400 [animation-delay:-0.3s]" />
                          <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-blue-400 [animation-delay:-0.15s]" />
                          <span className="h-2.5 w-2.5 animate-bounce rounded-full bg-blue-400" />
                        </div>

                        <p className="mt-3 text-sm text-slate-500">
                          {isTurkish
                            ? "Bilgi tabanı inceleniyor..."
                            : "Reviewing the knowledge base..."}
                        </p>
                      </div>
                    </article>
                  )}

                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>
          </div>

          {messages.length > 0 && (
          <div className="relative z-20 border-t border-white/10 bg-slate-950/90 px-4 py-4 backdrop-blur-xl sm:px-6">
            <div className="mx-auto max-w-6xl">
              {error && (
                <div className="mb-3 rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
                  ⚠️ {error}
                </div>
              )}

              <form
                onSubmit={handleSubmit}
                className="rounded-2xl border border-white/10 bg-white/[0.055] p-2 shadow-2xl shadow-black/20 transition focus-within:border-blue-500/40 focus-within:ring-4 focus-within:ring-blue-500/10"
              >
                <div className="flex items-end gap-2">
                  <textarea
                    ref={textareaRef}
                    value={question}
                    onChange={(event) => {
                      setQuestion(event.target.value);
                      setError("");
                    }}
                    onKeyDown={handleKeyDown}
                    disabled={loading}
                    rows={1}
                    className="max-h-36 min-h-12 flex-1 resize-none bg-transparent px-3 py-3 text-white outline-none placeholder:text-slate-600 disabled:cursor-not-allowed"
                    placeholder={
                      isTurkish
                        ? "SERNEM AI'a bir HSE sorusu sorun..."
                        : "Ask SERNEM AI an HSE question..."
                    }
                  />

                  <button
                    type="submit"
                    disabled={loading || !question.trim()}
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-xl font-black text-white shadow-lg shadow-blue-600/25 transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:bg-slate-800 disabled:text-slate-600"
                    aria-label={isTurkish ? "Soruyu gönder" : "Send question"}
                  >
                    ↑
                  </button>
                </div>
              </form>

              <p className="mt-2 text-center text-xs text-slate-600">
                {isTurkish
                  ? "Enter gönderir • Shift + Enter yeni satır"
                  : "Enter to send • Shift + Enter for a new line"}
              </p>
            </div>
          </div>
          )}
        </section>
      </div>
    </main>
  );
}
