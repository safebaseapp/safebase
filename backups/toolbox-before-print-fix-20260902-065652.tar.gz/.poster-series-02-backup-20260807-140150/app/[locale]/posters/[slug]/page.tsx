import Link from "next/link";
import { notFound } from "next/navigation";
import PosterMaster from "@/components/posters-v4/PosterMasterV4";
import PosterFormatToolbar from "@/components/posters-v4/PosterFormatToolbar";
import { workingAtHeightPoster } from "@/lib/posters-v2/working-at-height";
import { ladderSafetyPoster } from "@/lib/posters-v2/ladder-safety";
import { housekeepingSafetyPoster } from "@/lib/posters-v2/housekeeping-safety";
import { excavationSafetyPoster } from "@/lib/posters-v2/excavation-safety";
import { chemicalSafetyPoster } from "@/lib/posters-v2/chemical-safety";
import { forkliftSafetyPoster } from "@/lib/posters-v2/forklift-safety";
import { manualHandlingSafetyPoster } from "@/lib/posters-v2/manual-handling-safety";
import { droppedObjectsSafetyPoster } from "@/lib/posters-v2/dropped-objects-safety";
import { scaffoldPoster } from "@/lib/posters-v2/scaffold";
import { hotWorkPoster } from "@/lib/posters-v2/hot-work";
import { confinedSpacePoster } from "@/lib/posters-v2/confined-space";
import { electricalPoster } from "@/lib/posters-v2/electrical";
import { lotoPoster } from "@/lib/posters-v2/loto";
import { firePoster } from "@/lib/posters-v2/fire";
import { ppePoster } from "@/lib/posters-v2/ppe";

type Props = {
  params: Promise<{
    locale: string;
    slug: string;
  }>;
  searchParams: Promise<{
    size?: string;
    embed?: string;
  }>;
};

export default async function PosterDetailPage({
  params,
  searchParams,
}: Props) {
  const { locale, slug } = await params;
  const { size, embed } = await searchParams;

  if (locale !== "tr" && locale !== "en") {
    notFound();
  }

  const posterDefinitions = {
    "working-at-height-rules": workingAtHeightPoster,
  "ladder-safety-rules": ladderSafetyPoster,
    "housekeeping-safety-rules": housekeepingSafetyPoster,
    "excavation-safety-rules": excavationSafetyPoster,
    "chemical-safety-rules": chemicalSafetyPoster,
    "forklift-safety-rules": forkliftSafetyPoster,
    "manual-handling-safety-rules": manualHandlingSafetyPoster,
    "dropped-objects-safety-rules": droppedObjectsSafetyPoster,
    "scaffold-safety-rules": scaffoldPoster,
    "hot-work-safety-rules": hotWorkPoster,
    "confined-space-entry-rules": confinedSpacePoster,
    "electrical-safety-rules": electricalPoster,
    "loto-golden-rules": lotoPoster,
    "fire-safety-rules": firePoster,
    "mandatory-ppe": ppePoster,
  } as const;

  const selectedPoster =
    posterDefinitions[slug as keyof typeof posterDefinitions];

  if (!selectedPoster) {
    notFound();
  }

  const posterSize = size === "a4" ? "a4" : "a3";
  const isA4 = posterSize === "a4";
  const isTurkish = locale === "tr";
  const isEmbed = embed === "1";

  return (
    <>
      <style
        dangerouslySetInnerHTML={{
          __html: `
            @page {
              size: ${isA4 ? "A4" : "A3"} portrait;
              margin: 0;
            }

            @media print {
              html,
              body {
                width: ${isA4 ? "210mm" : "297mm"} !important;
                height: ${isA4 ? "297mm" : "420mm"} !important;
                margin: 0 !important;
                padding: 0 !important;
                overflow: hidden !important;
                background: white !important;
              }

              body * {
                visibility: hidden;
              }

              #poster-print-area,
              #poster-print-area * {
                visibility: visible;
              }

              #poster-controls {
                display: none !important;
              }

              #poster-print-area {
                position: absolute !important;
                inset: 0 !important;
                width: ${isA4 ? "210mm" : "297mm"} !important;
                height: ${isA4 ? "297mm" : "420mm"} !important;
                margin: 0 !important;
                overflow: hidden !important;
                box-shadow: none !important;
              }

              #poster-size-frame {
                position: relative !important;
                width: ${isA4 ? "210mm" : "297mm"} !important;
                height: ${isA4 ? "297mm" : "420mm"} !important;
                overflow: hidden !important;
              }

              #poster-scale-layer {
                position: absolute !important;
                left: 0 !important;
                top: 0 !important;
                width: 297mm !important;
                height: 420mm !important;
                scale: 1 !important;
                transform-origin: top left !important;
                transform: ${isA4 ? "scale(0.7070707)" : "none"} !important;
              }

              #safebase-poster {
                width: 297mm !important;
                height: 420mm !important;
                margin: 0 !important;
                box-shadow: none !important;
              }
            }
          `,
        }}
      />

      <main
        className={
          isEmbed
            ? "m-0 min-h-0 overflow-hidden bg-transparent p-0"
            : "min-h-screen bg-slate-200 px-5 py-10 print:min-h-0 print:bg-white print:p-0"
        }
      >
        {!isEmbed && (
        <div
          id="poster-controls"
          className="mx-auto mb-8 max-w-5xl rounded-[28px] border border-slate-300 bg-white p-6 shadow-xl print:hidden"
        >
          <Link
            href={`/${locale}/posters`}
            className="text-sm font-black text-blue-600 hover:text-slate-950"
          >
            ← {isTurkish ? "Poster Kütüphanesi" : "Poster Library"}
          </Link>

          <div className="mt-5 text-center">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-emerald-600">
              {selectedPoster.code} • SafeBase Pro Series
            </p>

            <h1 className="mt-3 text-3xl font-black text-slate-950">
              {selectedPoster.title[locale]}
            </h1>

            <p className="mt-2 text-sm font-semibold text-slate-600">
              {isTurkish ? "Seçili boyut" : "Selected size"}:{" "}
              <span className="font-black">
                {posterSize.toUpperCase()}
              </span>
            </p>
          </div>

          <div className="mt-6">
            <PosterFormatToolbar locale={locale} />
          </div>
        </div>
        )}

        <div
          id="poster-print-area"
          className={`mx-auto overflow-hidden bg-white print:shadow-none ${
            isEmbed ? "shadow-none" : "shadow-2xl"
          } ${
            isA4
              ? "h-[1123px] w-[794px]"
              : "h-[1588px] w-[1123px]"
          }`}
        >
          <div
            id="poster-size-frame"
            className={`relative overflow-hidden ${
              isA4
                ? "h-[1123px] w-[794px]"
                : "h-[1588px] w-[1123px]"
            }`}
          >
            <div
              id="poster-scale-layer"
              className={`absolute left-0 top-0 h-[1588px] w-[1123px] origin-top-left ${
                isA4 ? "scale-[0.7070707]" : ""
              }`}
            >
              <PosterMaster
                locale={locale}
                poster={selectedPoster}
              />
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
