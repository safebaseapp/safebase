export type RecommendationType =
  | "knowledge"
  | "checklist"
  | "toolbox"
  | "template";

export type Recommendation = {
  id: string;
  title: {
    tr: string;
    en: string;
  };
  description: {
    tr: string;
    en: string;
  };
  href: string;
  type: RecommendationType;
  icon: string;
};

type RecommendationGroup = {
  keywords: string[];
  recommendations: Recommendation[];
};

const groups: RecommendationGroup[] = [
  {
    keywords: [
      "hot work",
      "hotwork",
      "sıcak iş",
      "kaynak",
      "welding",
      "cutting",
      "grinding",
      "taşlama",
    ],
    recommendations: [
      {
        id: "hot-work-guide",
        title: {
          tr: "Sıcak İş Rehberi",
          en: "Hot Work Guide",
        },
        description: {
          tr: "Sıcak iş öncesi temel güvenlik kontrollerini inceleyin.",
          en: "Review essential safety controls before hot work.",
        },
        href: "/knowledge-base/hot-work",
        type: "knowledge",
        icon: "📚",
      },
      {
        id: "hot-work-checklist",
        title: {
          tr: "Sıcak İş Kontrol Listesi",
          en: "Hot Work Checklist",
        },
        description: {
          tr: "İşe başlamadan önce saha şartlarını kontrol edin.",
          en: "Check site conditions before work begins.",
        },
        href: "/checklists/hot-work",
        type: "checklist",
        icon: "📋",
      },
      {
        id: "hot-work-toolbox",
        title: {
          tr: "Sıcak İş Toolbox",
          en: "Hot Work Toolbox Talk",
        },
        description: {
          tr: "Ekibinizle paylaşabileceğiniz toolbox içeriği.",
          en: "Toolbox content ready to share with your team.",
        },
        href: "/downloads",
        type: "toolbox",
        icon: "🧰",
      },
      {
        id: "hot-work-permit",
        title: {
          tr: "Sıcak İş İzin Formu",
          en: "Hot Work Permit",
        },
        description: {
          tr: "Profesyonel sıcak iş izin şablonu.",
          en: "Professional hot work permit template.",
        },
        href: "/templates",
        type: "template",
        icon: "📄",
      },
    ],
  },
  {
    keywords: [
      "confined space",
      "kapalı alan",
      "tank entry",
      "vessel entry",
      "manhole",
    ],
    recommendations: [
      {
        id: "confined-space-guide",
        title: {
          tr: "Kapalı Alan Rehberi",
          en: "Confined Space Guide",
        },
        description: {
          tr: "Kapalı alan giriş şartlarını ve kontrolleri inceleyin.",
          en: "Review entry requirements and critical controls.",
        },
        href: "/knowledge-base/confined-space",
        type: "knowledge",
        icon: "📚",
      },
      {
        id: "confined-space-checklist",
        title: {
          tr: "Kapalı Alan Kontrol Listesi",
          en: "Confined Space Checklist",
        },
        description: {
          tr: "Gaz testi, kurtarma ve gözcü kontrollerini tamamlayın.",
          en: "Complete gas testing, rescue and standby checks.",
        },
        href: "/checklists/confined-space",
        type: "checklist",
        icon: "📋",
      },
      {
        id: "confined-space-toolbox",
        title: {
          tr: "Kapalı Alan Toolbox",
          en: "Confined Space Toolbox Talk",
        },
        description: {
          tr: "Kapalı alan çalışması için günlük toolbox içeriği.",
          en: "Daily toolbox content for confined space work.",
        },
        href: "/downloads",
        type: "toolbox",
        icon: "🧰",
      },
    ],
  },
  {
    keywords: [
      "loto",
      "lockout",
      "tagout",
      "energy isolation",
      "enerji izolasyonu",
      "kilitleme etiketleme",
    ],
    recommendations: [
      {
        id: "loto-guide",
        title: {
          tr: "LOTO Rehberi",
          en: "LOTO Guide",
        },
        description: {
          tr: "Enerji izolasyonu ve doğrulama adımlarını inceleyin.",
          en: "Review energy isolation and verification steps.",
        },
        href: "/knowledge-base/loto",
        type: "knowledge",
        icon: "📚",
      },
      {
        id: "loto-checklist",
        title: {
          tr: "LOTO Kontrol Listesi",
          en: "LOTO Checklist",
        },
        description: {
          tr: "Kilitleme ve sıfır enerji doğrulamasını kontrol edin.",
          en: "Check lockout and zero-energy verification.",
        },
        href: "/checklists/loto",
        type: "checklist",
        icon: "📋",
      },
      {
        id: "loto-toolbox",
        title: {
          tr: "LOTO Toolbox",
          en: "LOTO Toolbox Talk",
        },
        description: {
          tr: "LOTO uygulaması için ekip bilgilendirme içeriği.",
          en: "Team briefing content for LOTO activities.",
        },
        href: "/downloads",
        type: "toolbox",
        icon: "🧰",
      },
    ],
  },
  {
    keywords: [
      "scaffold",
      "scaffolding",
      "iskele",
      "trapdoor",
      "platform",
    ],
    recommendations: [
      {
        id: "scaffold-guide",
        title: {
          tr: "İskele Güvenliği Rehberi",
          en: "Scaffold Safety Guide",
        },
        description: {
          tr: "İskele erişimi, etiketleme ve kenar koruma şartları.",
          en: "Scaffold access, tagging and edge protection requirements.",
        },
        href: "/knowledge-base/scaffolding",
        type: "knowledge",
        icon: "📚",
      },
      {
        id: "scaffold-checklist",
        title: {
          tr: "İskele Kontrol Listesi",
          en: "Scaffold Inspection Checklist",
        },
        description: {
          tr: "İskele kullanım öncesi temel kontrollerini tamamlayın.",
          en: "Complete essential checks before scaffold use.",
        },
        href: "/checklists/scaffold",
        type: "checklist",
        icon: "📋",
      },
      {
        id: "scaffold-toolbox",
        title: {
          tr: "İskele Toolbox",
          en: "Scaffold Toolbox Talk",
        },
        description: {
          tr: "İskele kullanımı ve trapdoor güvenliği toolbox içeriği.",
          en: "Toolbox content for scaffold and trapdoor safety.",
        },
        href: "/downloads",
        type: "toolbox",
        icon: "🧰",
      },
    ],
  },
  {
    keywords: [
      "working at height",
      "work at height",
      "yüksekte çalışma",
      "fall protection",
      "emniyet kemeri",
      "harness",
      "lanyard",
    ],
    recommendations: [
      {
        id: "working-at-height-guide",
        title: {
          tr: "Yüksekte Çalışma Rehberi",
          en: "Working at Height Guide",
        },
        description: {
          tr: "Düşme riskleri, ankraj ve kurtarma şartlarını inceleyin.",
          en: "Review fall hazards, anchorage and rescue requirements.",
        },
        href: "/knowledge-base/working-at-height",
        type: "knowledge",
        icon: "📚",
      },
      {
        id: "working-at-height-checklist",
        title: {
          tr: "Yüksekte Çalışma Kontrol Listesi",
          en: "Working at Height Checklist",
        },
        description: {
          tr: "Ekipman, ankraj ve erişim kontrollerini tamamlayın.",
          en: "Complete equipment, anchorage and access checks.",
        },
        href: "/checklists/work-at-height",
        type: "checklist",
        icon: "📋",
      },
      {
        id: "working-at-height-toolbox",
        title: {
          tr: "Yüksekte Çalışma Toolbox",
          en: "Working at Height Toolbox Talk",
        },
        description: {
          tr: "Düşmeye karşı korunma için toolbox içeriği.",
          en: "Toolbox content for fall prevention.",
        },
        href: "/downloads",
        type: "toolbox",
        icon: "🧰",
      },
    ],
  },
];

export function getRecommendations(
  input: string,
  limit = 4
): Recommendation[] {
  const normalizedInput = input.trim().toLowerCase();

  if (!normalizedInput) {
    return [];
  }

  const matches = groups
    .map((group) => {
      const score = group.keywords.reduce((total, keyword) => {
        return normalizedInput.includes(keyword) ? total + 1 : total;
      }, 0);

      return {
        score,
        recommendations: group.recommendations,
      };
    })
    .filter((group) => group.score > 0)
    .sort((a, b) => b.score - a.score);

  const seen = new Set<string>();
  const results: Recommendation[] = [];

  for (const match of matches) {
    for (const recommendation of match.recommendations) {
      if (seen.has(recommendation.id)) {
        continue;
      }

      seen.add(recommendation.id);
      results.push(recommendation);

      if (results.length >= limit) {
        return results;
      }
    }
  }

  return results;
}
