type Locale = "tr" | "en";

type Props = {
  locale: Locale;
};

export default function PreJobStrip({ locale }: Props) {
  const isTurkish = locale === "tr";

  const checks = isTurkish
    ? [
        "Çalışma İzni",
        "Risk Değerlendirmesi",
        "Toolbox",
        "Kurtarma Planı",
        "Hava Koşulları",
        "KKD Kontrolü",
        "Alt Alan İzolasyonu",
      ]
    : [
        "Work Permit",
        "Risk Assessment",
        "Toolbox Talk",
        "Rescue Plan",
        "Weather",
        "PPE Check",
        "Area Isolation",
      ];

  return (
    <section className="mt-3 overflow-hidden rounded-[18px] border border-slate-300 bg-white shadow-sm">
      <div className="flex items-center justify-between bg-slate-950 px-5 py-2.5 text-white">
        <div className="flex items-center gap-3">
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500 text-sm font-black">
            ✓
          </span>

          <div>
            <p className="text-[8px] font-black uppercase tracking-[0.2em] text-emerald-400">
              Sernem Pre-Job Control
            </p>

            <h2 className="text-[16px] font-black uppercase leading-none">
              {isTurkish
                ? "İşe Başlamadan Önce Kontrol Et"
                : "Check Before Starting"}
            </h2>
          </div>
        </div>

        <span className="rounded-full border border-white/20 bg-white/10 px-3 py-1 text-[9px] font-black uppercase tracking-wider">
          30 SEC CHECK
        </span>
      </div>

      <div className="grid grid-cols-7 gap-2 p-3">
        {checks.map((item) => (
          <div
            key={item}
            className="flex min-h-[42px] items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2"
          >
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded border-2 border-emerald-600 bg-white text-[9px] font-black text-emerald-600">
              ✓
            </span>

            <span className="text-[8px] font-black uppercase leading-[1.2] text-slate-800">
              {item}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
